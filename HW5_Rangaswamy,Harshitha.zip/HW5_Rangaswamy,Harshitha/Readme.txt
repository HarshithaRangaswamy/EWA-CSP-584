Tomcat Start: C:\apache-tomcat-7.0.34\bin\startup
MySQL Start: C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql
MongoDb Start: C:\Program Files\MongoDB\Server\4.2\bin\mongod and mongo
Place the project folder inside the C:\apache-tomcat-7.0.34\webapps folder
Run the IPYNB files ProductRecommender and Assignment5BestBuyDeals
Run the application on the browser using the below URL:
https://localhost/Assignment_1